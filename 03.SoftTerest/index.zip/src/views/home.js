

const section = document.getElementById('homePage');

export function showHome(context) {
    context.showSection(section);
}